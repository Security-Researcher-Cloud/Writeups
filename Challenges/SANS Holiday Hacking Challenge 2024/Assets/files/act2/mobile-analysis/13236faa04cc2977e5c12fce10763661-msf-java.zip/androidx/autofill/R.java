package androidx.autofill;

/* loaded from: classes2.dex */
public final class R {

    /* loaded from: classes2.dex */
    public static final class attr {
        public static int alpha = 0x7f010000;
        public static int font = 0x7f010001;
        public static int fontProviderAuthority = 0x7f010002;
        public static int fontProviderCerts = 0x7f010003;
        public static int fontProviderFetchStrategy = 0x7f010004;
        public static int fontProviderFetchTimeout = 0x7f010005;
        public static int fontProviderPackage = 0x7f010006;
        public static int fontProviderQuery = 0x7f010007;
        public static int fontStyle = 0x7f010009;
        public static int fontVariationSettings = 0x7f01000a;
        public static int fontWeight = 0x7f01000b;
        public static int ttcIndex = 0x7f010010;

        private attr() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class color {
        public static int notification_action_color_filter = 0x7f020007;
        public static int notification_icon_bg_color = 0x7f020008;

        private color() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 0x7f030000;
        public static int compat_button_inset_vertical_material = 0x7f030001;
        public static int compat_button_padding_horizontal_material = 0x7f030002;
        public static int compat_button_padding_vertical_material = 0x7f030003;
        public static int compat_control_corner_material = 0x7f030004;
        public static int compat_notification_large_icon_max_height = 0x7f030005;
        public static int compat_notification_large_icon_max_width = 0x7f030006;
        public static int notification_action_icon_size = 0x7f030007;
        public static int notification_action_text_size = 0x7f030008;
        public static int notification_big_circle_margin = 0x7f030009;
        public static int notification_content_margin_start = 0x7f03000a;
        public static int notification_large_icon_height = 0x7f03000b;
        public static int notification_large_icon_width = 0x7f03000c;
        public static int notification_main_column_padding_top = 0x7f03000d;
        public static int notification_media_narrow_margin = 0x7f03000e;
        public static int notification_right_icon_size = 0x7f03000f;
        public static int notification_right_side_padding_top = 0x7f030010;
        public static int notification_small_icon_background_padding = 0x7f030011;
        public static int notification_small_icon_size_as_large = 0x7f030012;
        public static int notification_subtext_size = 0x7f030013;
        public static int notification_top_pad = 0x7f030014;
        public static int notification_top_pad_large_text = 0x7f030015;

        private dimen() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class drawable {
        public static int notification_action_background = 0x7f040009;
        public static int notification_bg = 0x7f04000a;
        public static int notification_bg_low = 0x7f04000b;
        public static int notification_bg_low_normal = 0x7f04000c;
        public static int notification_bg_low_pressed = 0x7f04000d;
        public static int notification_bg_normal = 0x7f04000e;
        public static int notification_bg_normal_pressed = 0x7f04000f;
        public static int notification_icon_background = 0x7f040010;
        public static int notification_template_icon_bg = 0x7f040012;
        public static int notification_template_icon_low_bg = 0x7f040013;
        public static int notification_tile_bg = 0x7f040014;
        public static int notify_panel_notification_icon_bg = 0x7f040015;

        private drawable() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class id {
        public static int accessibility_action_clickable_span = 0x7f050000;
        public static int accessibility_custom_action_0 = 0x7f050001;
        public static int accessibility_custom_action_1 = 0x7f050002;
        public static int accessibility_custom_action_10 = 0x7f050003;
        public static int accessibility_custom_action_11 = 0x7f050004;
        public static int accessibility_custom_action_12 = 0x7f050005;
        public static int accessibility_custom_action_13 = 0x7f050006;
        public static int accessibility_custom_action_14 = 0x7f050007;
        public static int accessibility_custom_action_15 = 0x7f050008;
        public static int accessibility_custom_action_16 = 0x7f050009;
        public static int accessibility_custom_action_17 = 0x7f05000a;
        public static int accessibility_custom_action_18 = 0x7f05000b;
        public static int accessibility_custom_action_19 = 0x7f05000c;
        public static int accessibility_custom_action_2 = 0x7f05000d;
        public static int accessibility_custom_action_20 = 0x7f05000e;
        public static int accessibility_custom_action_21 = 0x7f05000f;
        public static int accessibility_custom_action_22 = 0x7f050010;
        public static int accessibility_custom_action_23 = 0x7f050011;
        public static int accessibility_custom_action_24 = 0x7f050012;
        public static int accessibility_custom_action_25 = 0x7f050013;
        public static int accessibility_custom_action_26 = 0x7f050014;
        public static int accessibility_custom_action_27 = 0x7f050015;
        public static int accessibility_custom_action_28 = 0x7f050016;
        public static int accessibility_custom_action_29 = 0x7f050017;
        public static int accessibility_custom_action_3 = 0x7f050018;
        public static int accessibility_custom_action_30 = 0x7f050019;
        public static int accessibility_custom_action_31 = 0x7f05001a;
        public static int accessibility_custom_action_4 = 0x7f05001b;
        public static int accessibility_custom_action_5 = 0x7f05001c;
        public static int accessibility_custom_action_6 = 0x7f05001d;
        public static int accessibility_custom_action_7 = 0x7f05001e;
        public static int accessibility_custom_action_8 = 0x7f05001f;
        public static int accessibility_custom_action_9 = 0x7f050020;
        public static int action_container = 0x7f050021;
        public static int action_divider = 0x7f050022;
        public static int action_image = 0x7f050023;
        public static int action_text = 0x7f050024;
        public static int actions = 0x7f050025;
        public static int async = 0x7f050027;
        public static int blocking = 0x7f050028;
        public static int chronometer = 0x7f050029;
        public static int dialog_button = 0x7f05002c;
        public static int forever = 0x7f05002e;
        public static int icon = 0x7f050031;
        public static int icon_group = 0x7f050032;
        public static int info = 0x7f050033;
        public static int italic = 0x7f050036;
        public static int line1 = 0x7f050037;
        public static int line3 = 0x7f050038;
        public static int normal = 0x7f050039;
        public static int notification_background = 0x7f05003a;
        public static int notification_main_column = 0x7f05003b;
        public static int notification_main_column_container = 0x7f05003c;
        public static int right_icon = 0x7f05003f;
        public static int right_side = 0x7f050040;
        public static int tag_accessibility_actions = 0x7f050041;
        public static int tag_accessibility_clickable_spans = 0x7f050042;
        public static int tag_accessibility_heading = 0x7f050043;
        public static int tag_accessibility_pane_title = 0x7f050044;
        public static int tag_screen_reader_focusable = 0x7f050048;
        public static int tag_transition_group = 0x7f05004a;
        public static int tag_unhandled_key_event_manager = 0x7f05004b;
        public static int tag_unhandled_key_listeners = 0x7f05004c;
        public static int text = 0x7f05004e;
        public static int text2 = 0x7f05004f;
        public static int time = 0x7f050050;
        public static int title = 0x7f050051;

        private id() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class integer {
        public static int status_bar_notification_info_maxnum = 0x7f060000;

        private integer() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class layout {
        public static int custom_dialog = 0x7f070001;
        public static int notification_action = 0x7f070004;
        public static int notification_action_tombstone = 0x7f070005;
        public static int notification_template_custom_big = 0x7f070006;
        public static int notification_template_icon_group = 0x7f070007;
        public static int notification_template_part_chronometer = 0x7f070008;
        public static int notification_template_part_time = 0x7f070009;

        private layout() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class string {
        public static int status_bar_notification_info_overflow = 0x7f090040;

        private string() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class style {
        public static int TextAppearance_Compat_Notification = 0x7f0a0003;
        public static int TextAppearance_Compat_Notification_Info = 0x7f0a0004;
        public static int TextAppearance_Compat_Notification_Line2 = 0x7f0a0005;
        public static int TextAppearance_Compat_Notification_Time = 0x7f0a0006;
        public static int TextAppearance_Compat_Notification_Title = 0x7f0a0007;
        public static int Widget_Compat_NotificationActionContainer = 0x7f0a0009;
        public static int Widget_Compat_NotificationActionText = 0x7f0a000a;

        private style() {
        }
    }

    /* loaded from: classes2.dex */
    public static final class styleable {
        public static int ColorStateListItem_alpha = 0x00000003;
        public static int ColorStateListItem_android_alpha = 0x00000001;
        public static int ColorStateListItem_android_color = 0x00000000;
        public static int ColorStateListItem_android_lStar = 0x00000002;
        public static int ColorStateListItem_lStar = 0x00000004;
        public static int FontFamilyFont_android_font = 0x00000000;
        public static int FontFamilyFont_android_fontStyle = 0x00000002;
        public static int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static int FontFamilyFont_android_fontWeight = 0x00000001;
        public static int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static int FontFamilyFont_font = 0x00000005;
        public static int FontFamilyFont_fontStyle = 0x00000006;
        public static int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static int FontFamilyFont_fontWeight = 0x00000008;
        public static int FontFamilyFont_ttcIndex = 0x00000009;
        public static int FontFamily_fontProviderAuthority = 0x00000000;
        public static int FontFamily_fontProviderCerts = 0x00000001;
        public static int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static int FontFamily_fontProviderPackage = 0x00000004;
        public static int FontFamily_fontProviderQuery = 0x00000005;
        public static int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static int GradientColorItem_android_color = 0x00000000;
        public static int GradientColorItem_android_offset = 0x00000001;
        public static int GradientColor_android_centerColor = 0x00000007;
        public static int GradientColor_android_centerX = 0x00000003;
        public static int GradientColor_android_centerY = 0x00000004;
        public static int GradientColor_android_endColor = 0x00000001;
        public static int GradientColor_android_endX = 0x0000000a;
        public static int GradientColor_android_endY = 0x0000000b;
        public static int GradientColor_android_gradientRadius = 0x00000005;
        public static int GradientColor_android_startColor = 0x00000000;
        public static int GradientColor_android_startX = 0x00000008;
        public static int GradientColor_android_startY = 0x00000009;
        public static int GradientColor_android_tileMode = 0x00000006;
        public static int GradientColor_android_type = 0x00000002;
        public static int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, 16844359, com.northpole.santaswipe.R.attr.alpha, com.northpole.santaswipe.R.attr.lStar};
        public static int[] FontFamily = {com.northpole.santaswipe.R.attr.fontProviderAuthority, com.northpole.santaswipe.R.attr.fontProviderCerts, com.northpole.santaswipe.R.attr.fontProviderFetchStrategy, com.northpole.santaswipe.R.attr.fontProviderFetchTimeout, com.northpole.santaswipe.R.attr.fontProviderPackage, com.northpole.santaswipe.R.attr.fontProviderQuery, com.northpole.santaswipe.R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.northpole.santaswipe.R.attr.font, com.northpole.santaswipe.R.attr.fontStyle, com.northpole.santaswipe.R.attr.fontVariationSettings, com.northpole.santaswipe.R.attr.fontWeight, com.northpole.santaswipe.R.attr.ttcIndex};
        public static int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}
