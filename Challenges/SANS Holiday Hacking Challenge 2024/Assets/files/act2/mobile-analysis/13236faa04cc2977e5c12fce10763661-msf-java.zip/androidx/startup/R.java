package androidx.startup;

/* loaded from: classes2.dex */
public final class R {

    /* loaded from: classes2.dex */
    public static final class string {
        public static int androidx_startup = 0x7f090000;

        private string() {
        }
    }

    private R() {
    }
}
