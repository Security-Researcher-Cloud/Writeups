package androidx.webkit.internal;

/* loaded from: classes.dex */
public interface ConditionallySupportedFeature {
    String getPublicFeatureName();

    boolean isSupported();
}
