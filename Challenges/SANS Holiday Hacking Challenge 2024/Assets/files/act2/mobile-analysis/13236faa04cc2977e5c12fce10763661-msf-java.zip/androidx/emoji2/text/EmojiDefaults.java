package androidx.emoji2.text;

/* loaded from: classes.dex */
public class EmojiDefaults {
    public static final int MAX_EMOJI_COUNT = Integer.MAX_VALUE;

    private EmojiDefaults() {
    }
}
