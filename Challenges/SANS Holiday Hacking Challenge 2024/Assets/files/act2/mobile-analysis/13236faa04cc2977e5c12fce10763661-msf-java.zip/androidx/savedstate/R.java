package androidx.savedstate;

/* loaded from: classes2.dex */
public final class R {

    /* loaded from: classes2.dex */
    public static final class id {
        public static int view_tree_saved_state_registry_owner = 0x7f050054;

        private id() {
        }
    }

    private R() {
    }
}
