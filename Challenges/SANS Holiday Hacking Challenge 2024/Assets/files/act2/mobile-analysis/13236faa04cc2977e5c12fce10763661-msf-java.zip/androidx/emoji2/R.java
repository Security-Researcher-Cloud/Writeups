package androidx.emoji2;

/* loaded from: classes2.dex */
public final class R {
    private R() {
    }
}
