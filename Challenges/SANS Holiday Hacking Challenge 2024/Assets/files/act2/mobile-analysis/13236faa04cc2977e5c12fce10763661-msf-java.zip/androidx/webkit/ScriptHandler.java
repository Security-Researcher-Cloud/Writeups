package androidx.webkit;

/* loaded from: classes.dex */
public interface ScriptHandler {
    void remove();
}
