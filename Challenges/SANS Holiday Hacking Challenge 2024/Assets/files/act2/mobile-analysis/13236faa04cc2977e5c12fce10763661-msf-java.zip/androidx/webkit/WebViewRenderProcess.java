package androidx.webkit;

/* loaded from: classes.dex */
public abstract class WebViewRenderProcess {
    public abstract boolean terminate();
}
