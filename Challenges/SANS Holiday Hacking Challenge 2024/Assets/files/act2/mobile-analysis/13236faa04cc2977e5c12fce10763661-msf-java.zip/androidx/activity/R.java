package androidx.activity;

/* loaded from: classes2.dex */
public final class R {

    /* loaded from: classes2.dex */
    public static final class id {
        public static int report_drawn = 0x7f05003e;
        public static int view_tree_on_back_pressed_dispatcher_owner = 0x7f050053;

        private id() {
        }
    }

    private R() {
    }
}
