package androidx.customview.poolingcontainer;

/* loaded from: classes2.dex */
public final class R {

    /* loaded from: classes2.dex */
    public static final class id {
        public static int is_pooling_container_tag = 0x7f050035;
        public static int pooling_container_listener_holder_tag = 0x7f05003d;

        private id() {
        }
    }

    private R() {
    }
}
