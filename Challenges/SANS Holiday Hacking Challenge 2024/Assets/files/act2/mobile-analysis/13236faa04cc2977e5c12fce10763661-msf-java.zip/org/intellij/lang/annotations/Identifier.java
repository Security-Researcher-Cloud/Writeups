package org.intellij.lang.annotations;

/* loaded from: classes5.dex */
public @interface Identifier {
}
