package org.chromium.support_lib_boundary;

/* loaded from: classes5.dex */
public interface WebResourceErrorBoundaryInterface {
    CharSequence getDescription();

    int getErrorCode();
}
