package org.chromium.support_lib_boundary;

import android.content.Intent;

/* loaded from: classes5.dex */
public interface WebAuthnCallbackBoundaryInterface {
    void onResult(int i, Intent intent);
}
