package androidx.lifecycle.ktx;

public final class R {
    private R() {
    }
}
