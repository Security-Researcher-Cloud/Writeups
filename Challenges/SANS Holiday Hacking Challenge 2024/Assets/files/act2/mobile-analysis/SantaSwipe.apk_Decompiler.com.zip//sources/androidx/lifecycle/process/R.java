package androidx.lifecycle.process;

public final class R {
    private R() {
    }
}
