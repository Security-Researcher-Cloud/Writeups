package androidx.lifecycle.runtime;

public final class R {

    public static final class id {
        public static int view_tree_lifecycle_owner = 2131034194;

        private id() {
        }
    }

    private R() {
    }
}
