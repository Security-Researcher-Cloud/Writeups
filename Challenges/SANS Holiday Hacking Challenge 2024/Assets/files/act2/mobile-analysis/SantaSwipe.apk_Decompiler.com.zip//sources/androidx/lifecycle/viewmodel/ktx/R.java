package androidx.lifecycle.viewmodel.ktx;

public final class R {
    private R() {
    }
}
