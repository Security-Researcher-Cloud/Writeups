package androidx.lifecycle;

import android.app.Application;
import androidx.lifecycle.viewmodel.CreationExtras;
import kotlin.Metadata;

@Metadata(d1 = {"\u0000\u000f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001¨\u0006\u0003"}, d2 = {"androidx/lifecycle/ViewModelProvider$AndroidViewModelFactory$Companion$APPLICATION_KEY$1", "Landroidx/lifecycle/viewmodel/CreationExtras$Key;", "Landroid/app/Application;", "lifecycle-viewmodel_release"}, k = 1, mv = {1, 8, 0}, xi = 48)
/* compiled from: ViewModelProvider.android.kt */
public final class ViewModelProvider$AndroidViewModelFactory$Companion$APPLICATION_KEY$1 implements CreationExtras.Key<Application> {
    ViewModelProvider$AndroidViewModelFactory$Companion$APPLICATION_KEY$1() {
    }
}
