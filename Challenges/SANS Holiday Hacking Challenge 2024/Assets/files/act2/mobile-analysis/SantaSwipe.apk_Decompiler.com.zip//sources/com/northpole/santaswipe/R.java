package com.northpole.santaswipe;

public final class R {

    public static final class color {
        public static int black = 2130837506;
        public static int ic_launcher_background = 2130837509;
        public static int ic_launcher_background_chc = 2130837510;
        public static int purple_200 = 2130837513;
        public static int purple_500 = 2130837514;
        public static int purple_700 = 2130837515;
        public static int teal_200 = 2130837516;
        public static int teal_700 = 2130837517;
        public static int white = 2130837520;
        /* added by JADX */
        public static final int androidx_core_ripple_material_light = 2130837504;
        /* added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 2130837505;
        /* added by JADX */
        public static final int call_notification_answer_color = 2130837507;
        /* added by JADX */
        public static final int call_notification_decline_color = 2130837508;
        /* added by JADX */
        public static final int notification_action_color_filter = 2130837511;
        /* added by JADX */
        public static final int notification_icon_bg_color = 2130837512;
        /* added by JADX */
        public static final int vector_tint_color = 2130837518;
        /* added by JADX */
        public static final int vector_tint_theme_color = 2130837519;

        private color() {
        }
    }

    public static final class drawable {
        public static int ic_launcher_background = 2130968582;
        public static int ic_launcher_chc_foreground = 2130968583;
        public static int ic_launcher_foreground = 2130968584;
        /* added by JADX */
        public static final int ic_call_answer = 2130968576;
        /* added by JADX */
        public static final int ic_call_answer_low = 2130968577;
        /* added by JADX */
        public static final int ic_call_answer_video = 2130968578;
        /* added by JADX */
        public static final int ic_call_answer_video_low = 2130968579;
        /* added by JADX */
        public static final int ic_call_decline = 2130968580;
        /* added by JADX */
        public static final int ic_call_decline_low = 2130968581;
        /* added by JADX */
        public static final int notification_action_background = 2130968585;
        /* added by JADX */
        public static final int notification_bg = 2130968586;
        /* added by JADX */
        public static final int notification_bg_low = 2130968587;
        /* added by JADX */
        public static final int notification_bg_low_normal = 2130968588;
        /* added by JADX */
        public static final int notification_bg_low_pressed = 2130968589;
        /* added by JADX */
        public static final int notification_bg_normal = 2130968590;
        /* added by JADX */
        public static final int notification_bg_normal_pressed = 2130968591;
        /* added by JADX */
        public static final int notification_icon_background = 2130968592;
        /* added by JADX */
        public static final int notification_oversize_large_icon_bg = 2130968593;
        /* added by JADX */
        public static final int notification_template_icon_bg = 2130968594;
        /* added by JADX */
        public static final int notification_template_icon_low_bg = 2130968595;
        /* added by JADX */
        public static final int notification_tile_bg = 2130968596;
        /* added by JADX */
        public static final int notify_panel_notification_icon_bg = 2130968597;

        private drawable() {
        }
    }

    public static final class id {
        public static int webview = 2131034198;
        /* added by JADX */
        public static final int accessibility_action_clickable_span = 2131034112;
        /* added by JADX */
        public static final int accessibility_custom_action_0 = 2131034113;
        /* added by JADX */
        public static final int accessibility_custom_action_1 = 2131034114;
        /* added by JADX */
        public static final int accessibility_custom_action_10 = 2131034115;
        /* added by JADX */
        public static final int accessibility_custom_action_11 = 2131034116;
        /* added by JADX */
        public static final int accessibility_custom_action_12 = 2131034117;
        /* added by JADX */
        public static final int accessibility_custom_action_13 = 2131034118;
        /* added by JADX */
        public static final int accessibility_custom_action_14 = 2131034119;
        /* added by JADX */
        public static final int accessibility_custom_action_15 = 2131034120;
        /* added by JADX */
        public static final int accessibility_custom_action_16 = 2131034121;
        /* added by JADX */
        public static final int accessibility_custom_action_17 = 2131034122;
        /* added by JADX */
        public static final int accessibility_custom_action_18 = 2131034123;
        /* added by JADX */
        public static final int accessibility_custom_action_19 = 2131034124;
        /* added by JADX */
        public static final int accessibility_custom_action_2 = 2131034125;
        /* added by JADX */
        public static final int accessibility_custom_action_20 = 2131034126;
        /* added by JADX */
        public static final int accessibility_custom_action_21 = 2131034127;
        /* added by JADX */
        public static final int accessibility_custom_action_22 = 2131034128;
        /* added by JADX */
        public static final int accessibility_custom_action_23 = 2131034129;
        /* added by JADX */
        public static final int accessibility_custom_action_24 = 2131034130;
        /* added by JADX */
        public static final int accessibility_custom_action_25 = 2131034131;
        /* added by JADX */
        public static final int accessibility_custom_action_26 = 2131034132;
        /* added by JADX */
        public static final int accessibility_custom_action_27 = 2131034133;
        /* added by JADX */
        public static final int accessibility_custom_action_28 = 2131034134;
        /* added by JADX */
        public static final int accessibility_custom_action_29 = 2131034135;
        /* added by JADX */
        public static final int accessibility_custom_action_3 = 2131034136;
        /* added by JADX */
        public static final int accessibility_custom_action_30 = 2131034137;
        /* added by JADX */
        public static final int accessibility_custom_action_31 = 2131034138;
        /* added by JADX */
        public static final int accessibility_custom_action_4 = 2131034139;
        /* added by JADX */
        public static final int accessibility_custom_action_5 = 2131034140;
        /* added by JADX */
        public static final int accessibility_custom_action_6 = 2131034141;
        /* added by JADX */
        public static final int accessibility_custom_action_7 = 2131034142;
        /* added by JADX */
        public static final int accessibility_custom_action_8 = 2131034143;
        /* added by JADX */
        public static final int accessibility_custom_action_9 = 2131034144;
        /* added by JADX */
        public static final int action_container = 2131034145;
        /* added by JADX */
        public static final int action_divider = 2131034146;
        /* added by JADX */
        public static final int action_image = 2131034147;
        /* added by JADX */
        public static final int action_text = 2131034148;
        /* added by JADX */
        public static final int actions = 2131034149;
        /* added by JADX */
        public static final int androidx_compose_ui_view_composition_context = 2131034150;
        /* added by JADX */
        public static final int async = 2131034151;
        /* added by JADX */
        public static final int blocking = 2131034152;
        /* added by JADX */
        public static final int chronometer = 2131034153;
        /* added by JADX */
        public static final int compose_view_saveable_id_tag = 2131034154;
        /* added by JADX */
        public static final int consume_window_insets_tag = 2131034155;
        /* added by JADX */
        public static final int dialog_button = 2131034156;
        /* added by JADX */
        public static final int edit_text_id = 2131034157;
        /* added by JADX */
        public static final int forever = 2131034158;
        /* added by JADX */
        public static final int hide_ime_id = 2131034159;
        /* added by JADX */
        public static final int hide_in_inspector_tag = 2131034160;
        /* added by JADX */
        public static final int icon = 2131034161;
        /* added by JADX */
        public static final int icon_group = 2131034162;
        /* added by JADX */
        public static final int info = 2131034163;
        /* added by JADX */
        public static final int inspection_slot_table_set = 2131034164;
        /* added by JADX */
        public static final int is_pooling_container_tag = 2131034165;
        /* added by JADX */
        public static final int italic = 2131034166;
        /* added by JADX */
        public static final int line1 = 2131034167;
        /* added by JADX */
        public static final int line3 = 2131034168;
        /* added by JADX */
        public static final int normal = 2131034169;
        /* added by JADX */
        public static final int notification_background = 2131034170;
        /* added by JADX */
        public static final int notification_main_column = 2131034171;
        /* added by JADX */
        public static final int notification_main_column_container = 2131034172;
        /* added by JADX */
        public static final int pooling_container_listener_holder_tag = 2131034173;
        /* added by JADX */
        public static final int report_drawn = 2131034174;
        /* added by JADX */
        public static final int right_icon = 2131034175;
        /* added by JADX */
        public static final int right_side = 2131034176;
        /* added by JADX */
        public static final int tag_accessibility_actions = 2131034177;
        /* added by JADX */
        public static final int tag_accessibility_clickable_spans = 2131034178;
        /* added by JADX */
        public static final int tag_accessibility_heading = 2131034179;
        /* added by JADX */
        public static final int tag_accessibility_pane_title = 2131034180;
        /* added by JADX */
        public static final int tag_on_apply_window_listener = 2131034181;
        /* added by JADX */
        public static final int tag_on_receive_content_listener = 2131034182;
        /* added by JADX */
        public static final int tag_on_receive_content_mime_types = 2131034183;
        /* added by JADX */
        public static final int tag_screen_reader_focusable = 2131034184;
        /* added by JADX */
        public static final int tag_state_description = 2131034185;
        /* added by JADX */
        public static final int tag_transition_group = 2131034186;
        /* added by JADX */
        public static final int tag_unhandled_key_event_manager = 2131034187;
        /* added by JADX */
        public static final int tag_unhandled_key_listeners = 2131034188;
        /* added by JADX */
        public static final int tag_window_insets_animation_callback = 2131034189;
        /* added by JADX */
        public static final int text = 2131034190;
        /* added by JADX */
        public static final int text2 = 2131034191;
        /* added by JADX */
        public static final int time = 2131034192;
        /* added by JADX */
        public static final int title = 2131034193;
        /* added by JADX */
        public static final int view_tree_lifecycle_owner = 2131034194;
        /* added by JADX */
        public static final int view_tree_on_back_pressed_dispatcher_owner = 2131034195;
        /* added by JADX */
        public static final int view_tree_saved_state_registry_owner = 2131034196;
        /* added by JADX */
        public static final int view_tree_view_model_store_owner = 2131034197;
        /* added by JADX */
        public static final int wrapped_composition_tag = 2131034199;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_main = 2131165184;
        /* added by JADX */
        public static final int custom_dialog = 2131165185;
        /* added by JADX */
        public static final int ime_base_split_test_activity = 2131165186;
        /* added by JADX */
        public static final int ime_secondary_split_test_activity = 2131165187;
        /* added by JADX */
        public static final int notification_action = 2131165188;
        /* added by JADX */
        public static final int notification_action_tombstone = 2131165189;
        /* added by JADX */
        public static final int notification_template_custom_big = 2131165190;
        /* added by JADX */
        public static final int notification_template_icon_group = 2131165191;
        /* added by JADX */
        public static final int notification_template_part_chronometer = 2131165192;
        /* added by JADX */
        public static final int notification_template_part_time = 2131165193;

        private layout() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 2131230720;
        public static int ic_launcher_chc = 2131230721;
        public static int ic_launcher_chc_round = 2131230722;
        public static int ic_launcher_foreground = 2131230723;
        public static int ic_launcher_round = 2131230724;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 2131296257;
        /* added by JADX */
        public static final int androidx_startup = 2131296256;
        /* added by JADX */
        public static final int bottom_sheet_collapse_description = 2131296258;
        /* added by JADX */
        public static final int bottom_sheet_dismiss_description = 2131296259;
        /* added by JADX */
        public static final int bottom_sheet_drag_handle_description = 2131296260;
        /* added by JADX */
        public static final int bottom_sheet_expand_description = 2131296261;
        /* added by JADX */
        public static final int call_notification_answer_action = 2131296262;
        /* added by JADX */
        public static final int call_notification_answer_video_action = 2131296263;
        /* added by JADX */
        public static final int call_notification_decline_action = 2131296264;
        /* added by JADX */
        public static final int call_notification_hang_up_action = 2131296265;
        /* added by JADX */
        public static final int call_notification_incoming_text = 2131296266;
        /* added by JADX */
        public static final int call_notification_ongoing_text = 2131296267;
        /* added by JADX */
        public static final int call_notification_screening_text = 2131296268;
        /* added by JADX */
        public static final int close_drawer = 2131296269;
        /* added by JADX */
        public static final int close_sheet = 2131296270;
        /* added by JADX */
        public static final int collapsed = 2131296271;
        /* added by JADX */
        public static final int date_input_headline = 2131296272;
        /* added by JADX */
        public static final int date_input_headline_description = 2131296273;
        /* added by JADX */
        public static final int date_input_invalid_for_pattern = 2131296274;
        /* added by JADX */
        public static final int date_input_invalid_not_allowed = 2131296275;
        /* added by JADX */
        public static final int date_input_invalid_year_range = 2131296276;
        /* added by JADX */
        public static final int date_input_label = 2131296277;
        /* added by JADX */
        public static final int date_input_no_input_description = 2131296278;
        /* added by JADX */
        public static final int date_input_title = 2131296279;
        /* added by JADX */
        public static final int date_picker_headline = 2131296280;
        /* added by JADX */
        public static final int date_picker_headline_description = 2131296281;
        /* added by JADX */
        public static final int date_picker_navigate_to_year_description = 2131296282;
        /* added by JADX */
        public static final int date_picker_no_selection_description = 2131296283;
        /* added by JADX */
        public static final int date_picker_scroll_to_earlier_years = 2131296284;
        /* added by JADX */
        public static final int date_picker_scroll_to_later_years = 2131296285;
        /* added by JADX */
        public static final int date_picker_switch_to_calendar_mode = 2131296286;
        /* added by JADX */
        public static final int date_picker_switch_to_day_selection = 2131296287;
        /* added by JADX */
        public static final int date_picker_switch_to_input_mode = 2131296288;
        /* added by JADX */
        public static final int date_picker_switch_to_next_month = 2131296289;
        /* added by JADX */
        public static final int date_picker_switch_to_previous_month = 2131296290;
        /* added by JADX */
        public static final int date_picker_switch_to_year_selection = 2131296291;
        /* added by JADX */
        public static final int date_picker_title = 2131296292;
        /* added by JADX */
        public static final int date_picker_today_description = 2131296293;
        /* added by JADX */
        public static final int date_picker_year_picker_pane_title = 2131296294;
        /* added by JADX */
        public static final int date_range_input_invalid_range_input = 2131296295;
        /* added by JADX */
        public static final int date_range_input_title = 2131296296;
        /* added by JADX */
        public static final int date_range_picker_day_in_range = 2131296297;
        /* added by JADX */
        public static final int date_range_picker_end_headline = 2131296298;
        /* added by JADX */
        public static final int date_range_picker_scroll_to_next_month = 2131296299;
        /* added by JADX */
        public static final int date_range_picker_scroll_to_previous_month = 2131296300;
        /* added by JADX */
        public static final int date_range_picker_start_headline = 2131296301;
        /* added by JADX */
        public static final int date_range_picker_title = 2131296302;
        /* added by JADX */
        public static final int default_error_message = 2131296303;
        /* added by JADX */
        public static final int default_popup_window_title = 2131296304;
        /* added by JADX */
        public static final int dialog = 2131296305;
        /* added by JADX */
        public static final int dropdown_menu = 2131296306;
        /* added by JADX */
        public static final int expanded = 2131296307;
        /* added by JADX */
        public static final int in_progress = 2131296308;
        /* added by JADX */
        public static final int indeterminate = 2131296309;
        /* added by JADX */
        public static final int m3c_bottom_sheet_pane_title = 2131296310;
        /* added by JADX */
        public static final int navigation_menu = 2131296311;
        /* added by JADX */
        public static final int not_selected = 2131296312;
        /* added by JADX */
        public static final int off = 2131296313;
        /* added by JADX */
        public static final int on = 2131296314;
        /* added by JADX */
        public static final int range_end = 2131296315;
        /* added by JADX */
        public static final int range_start = 2131296316;
        /* added by JADX */
        public static final int search_bar_search = 2131296317;
        /* added by JADX */
        public static final int selected = 2131296318;
        /* added by JADX */
        public static final int snackbar_dismiss = 2131296319;
        /* added by JADX */
        public static final int status_bar_notification_info_overflow = 2131296320;
        /* added by JADX */
        public static final int suggestions_available = 2131296321;
        /* added by JADX */
        public static final int switch_role = 2131296322;
        /* added by JADX */
        public static final int tab = 2131296323;
        /* added by JADX */
        public static final int template_percent = 2131296324;
        /* added by JADX */
        public static final int time_picker_am = 2131296325;
        /* added by JADX */
        public static final int time_picker_hour = 2131296326;
        /* added by JADX */
        public static final int time_picker_hour_24h_suffix = 2131296327;
        /* added by JADX */
        public static final int time_picker_hour_selection = 2131296328;
        /* added by JADX */
        public static final int time_picker_hour_suffix = 2131296329;
        /* added by JADX */
        public static final int time_picker_hour_text_field = 2131296330;
        /* added by JADX */
        public static final int time_picker_minute = 2131296331;
        /* added by JADX */
        public static final int time_picker_minute_selection = 2131296332;
        /* added by JADX */
        public static final int time_picker_minute_suffix = 2131296333;
        /* added by JADX */
        public static final int time_picker_minute_text_field = 2131296334;
        /* added by JADX */
        public static final int time_picker_period_toggle_description = 2131296335;
        /* added by JADX */
        public static final int time_picker_pm = 2131296336;
        /* added by JADX */
        public static final int tooltip_long_press_label = 2131296337;
        /* added by JADX */
        public static final int tooltip_pane_description = 2131296338;

        private string() {
        }
    }

    public static final class style {
        public static int Theme_SantaSwipe = 2131361800;
        /* added by JADX */
        public static final int DialogWindowTheme = 2131361792;
        /* added by JADX */
        public static final int FloatingDialogTheme = 2131361793;
        /* added by JADX */
        public static final int FloatingDialogWindowTheme = 2131361794;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification = 2131361795;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 2131361796;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 2131361797;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 2131361798;
        /* added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 2131361799;
        /* added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 2131361801;
        /* added by JADX */
        public static final int Widget_Compat_NotificationActionText = 2131361802;

        private style() {
        }
    }

    public static final class xml {
        public static int backup_rules = 2131492864;
        public static int data_extraction_rules = 2131492865;

        private xml() {
        }
    }

    /* added by JADX */
    public static final class attr {
        /* added by JADX */
        public static final int alpha = 2130771968;
        /* added by JADX */
        public static final int font = 2130771969;
        /* added by JADX */
        public static final int fontProviderAuthority = 2130771970;
        /* added by JADX */
        public static final int fontProviderCerts = 2130771971;
        /* added by JADX */
        public static final int fontProviderFetchStrategy = 2130771972;
        /* added by JADX */
        public static final int fontProviderFetchTimeout = 2130771973;
        /* added by JADX */
        public static final int fontProviderPackage = 2130771974;
        /* added by JADX */
        public static final int fontProviderQuery = 2130771975;
        /* added by JADX */
        public static final int fontProviderSystemFontFamily = 2130771976;
        /* added by JADX */
        public static final int fontStyle = 2130771977;
        /* added by JADX */
        public static final int fontVariationSettings = 2130771978;
        /* added by JADX */
        public static final int fontWeight = 2130771979;
        /* added by JADX */
        public static final int lStar = 2130771980;
        /* added by JADX */
        public static final int nestedScrollViewStyle = 2130771981;
        /* added by JADX */
        public static final int queryPatterns = 2130771982;
        /* added by JADX */
        public static final int shortcutMatchRequired = 2130771983;
        /* added by JADX */
        public static final int ttcIndex = 2130771984;
    }

    /* added by JADX */
    public static final class dimen {
        /* added by JADX */
        public static final int compat_button_inset_horizontal_material = 2130903040;
        /* added by JADX */
        public static final int compat_button_inset_vertical_material = 2130903041;
        /* added by JADX */
        public static final int compat_button_padding_horizontal_material = 2130903042;
        /* added by JADX */
        public static final int compat_button_padding_vertical_material = 2130903043;
        /* added by JADX */
        public static final int compat_control_corner_material = 2130903044;
        /* added by JADX */
        public static final int compat_notification_large_icon_max_height = 2130903045;
        /* added by JADX */
        public static final int compat_notification_large_icon_max_width = 2130903046;
        /* added by JADX */
        public static final int notification_action_icon_size = 2130903047;
        /* added by JADX */
        public static final int notification_action_text_size = 2130903048;
        /* added by JADX */
        public static final int notification_big_circle_margin = 2130903049;
        /* added by JADX */
        public static final int notification_content_margin_start = 2130903050;
        /* added by JADX */
        public static final int notification_large_icon_height = 2130903051;
        /* added by JADX */
        public static final int notification_large_icon_width = 2130903052;
        /* added by JADX */
        public static final int notification_main_column_padding_top = 2130903053;
        /* added by JADX */
        public static final int notification_media_narrow_margin = 2130903054;
        /* added by JADX */
        public static final int notification_right_icon_size = 2130903055;
        /* added by JADX */
        public static final int notification_right_side_padding_top = 2130903056;
        /* added by JADX */
        public static final int notification_small_icon_background_padding = 2130903057;
        /* added by JADX */
        public static final int notification_small_icon_size_as_large = 2130903058;
        /* added by JADX */
        public static final int notification_subtext_size = 2130903059;
        /* added by JADX */
        public static final int notification_top_pad = 2130903060;
        /* added by JADX */
        public static final int notification_top_pad_large_text = 2130903061;
    }

    /* added by JADX */
    public static final class integer {
        /* added by JADX */
        public static final int status_bar_notification_info_maxnum = 2131099648;
    }

    private R() {
    }
}
