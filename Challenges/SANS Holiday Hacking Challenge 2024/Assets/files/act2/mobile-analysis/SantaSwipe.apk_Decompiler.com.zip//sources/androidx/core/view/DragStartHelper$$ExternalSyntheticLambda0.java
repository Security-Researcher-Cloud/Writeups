package androidx.core.view;

import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class DragStartHelper$$ExternalSyntheticLambda0 implements View.OnLongClickListener {
    public final /* synthetic */ DragStartHelper f$0;

    public /* synthetic */ DragStartHelper$$ExternalSyntheticLambda0(DragStartHelper dragStartHelper) {
        this.f$0 = dragStartHelper;
    }

    public final boolean onLongClick(View view) {
        return this.f$0.onLongClick(view);
    }
}
