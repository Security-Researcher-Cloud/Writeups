package com.northpole.santaswipe;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import androidx.activity.ComponentActivity;
import androidx.webkit.WebViewAssetLoader;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;

@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001\u000bB\u0005¢\u0006\u0002\u0010\u0002J\u0012\u0010\u0007\u001a\u00020\b2\b\u0010\t\u001a\u0004\u0018\u00010\nH\u0014R\u000e\u0010\u0003\u001a\u00020\u0004X.¢\u0006\u0002\n\u0000R\u000e\u0010\u0005\u001a\u00020\u0006X.¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"Lcom/northpole/santaswipe/MainActivity;", "Landroidx/activity/ComponentActivity;", "()V", "database", "Landroid/database/sqlite/SQLiteDatabase;", "myWebView", "Landroid/webkit/WebView;", "onCreate", "", "savedInstanceState", "Landroid/os/Bundle;", "WebAppInterface", "app_debug"}, k = 1, mv = {1, 9, 0}, xi = 48)
/* compiled from: MainActivity.kt */
public final class MainActivity extends ComponentActivity {
    public static final int $stable = 8;
    /* access modifiers changed from: private */
    public SQLiteDatabase database;
    /* access modifiers changed from: private */
    public WebView myWebView;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SQLiteDatabase writableDatabase = new DatabaseHelper(this).getWritableDatabase();
        Intrinsics.checkNotNullExpressionValue(writableDatabase, "getWritableDatabase(...)");
        this.database = writableDatabase;
        View findViewById = findViewById(R.id.webview);
        Intrinsics.checkNotNullExpressionValue(findViewById, "findViewById(...)");
        this.myWebView = (WebView) findViewById;
        WebView webView = this.myWebView;
        WebView webView2 = null;
        if (webView == null) {
            Intrinsics.throwUninitializedPropertyAccessException("myWebView");
            webView = null;
        }
        webView.getSettings().setJavaScriptEnabled(true);
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler((Context) this)).addPathHandler("/res/", new WebViewAssetLoader.ResourcesPathHandler((Context) this)).build();
        Intrinsics.checkNotNullExpressionValue(assetLoader, "build(...)");
        WebView webView3 = this.myWebView;
        if (webView3 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("myWebView");
            webView3 = null;
        }
        webView3.setWebViewClient(new MainActivity$onCreate$1(assetLoader));
        WebView webView4 = this.myWebView;
        if (webView4 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("myWebView");
            webView4 = null;
        }
        webView4.addJavascriptInterface(new WebAppInterface(), "Android");
        WebView webView5 = this.myWebView;
        if (webView5 == null) {
            Intrinsics.throwUninitializedPropertyAccessException("myWebView");
        } else {
            webView2 = webView5;
        }
        webView2.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\b\u0004\u0018\u00002\u00020\u0001B\u0005¢\u0006\u0002\u0010\u0002J\u0010\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\u0010\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0007J\b\u0010\b\u001a\u00020\u0004H\u0007J\b\u0010\t\u001a\u00020\u0004H\u0007J\b\u0010\n\u001a\u00020\u0004H\u0007J\u0010\u0010\u000b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0006H\u0002¨\u0006\f"}, d2 = {"Lcom/northpole/santaswipe/MainActivity$WebAppInterface;", "", "(Lcom/northpole/santaswipe/MainActivity;)V", "addToNaughtyList", "", "item", "", "addToNiceList", "getNaughtyList", "getNiceList", "getNormalList", "removeFromAllLists", "app_debug"}, k = 1, mv = {1, 9, 0}, xi = 48)
    /* compiled from: MainActivity.kt */
    public final class WebAppInterface {
        public WebAppInterface() {
        }

        @JavascriptInterface
        public final void addToNiceList(String item) {
            Intrinsics.checkNotNullParameter(item, "item");
            try {
                removeFromAllLists(item);
                SQLiteDatabase access$getDatabase$p = MainActivity.this.database;
                if (access$getDatabase$p == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p = null;
                }
                access$getDatabase$p.execSQL("INSERT INTO NiceList (Item) VALUES ('" + item + "');");
            } catch (Exception e) {
                Log.e("WebAppInterface", "Error adding to NiceList: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public final void addToNaughtyList(String item) {
            Intrinsics.checkNotNullParameter(item, "item");
            try {
                removeFromAllLists(item);
                SQLiteDatabase access$getDatabase$p = MainActivity.this.database;
                if (access$getDatabase$p == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p = null;
                }
                access$getDatabase$p.execSQL("INSERT INTO NaughtyList (Item) VALUES ('" + item + "');");
            } catch (Exception e) {
                Log.e("WebAppInterface", "Error adding to NaughtyList: " + e.getMessage());
            }
        }

        @JavascriptInterface
        public final void getNormalList() {
            String jsonItems;
            try {
                SQLiteDatabase access$getDatabase$p = MainActivity.this.database;
                if (access$getDatabase$p == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p = null;
                }
                Cursor cursor = access$getDatabase$p.rawQuery("SELECT Item FROM NormalList WHERE Item NOT LIKE '%Ellie%'", (String[]) null);
                List items = new ArrayList();
                Log.d("WebAppInterface", "Fetching items from NormalList table");
                while (cursor.moveToNext()) {
                    String item = cursor.getString(0);
                    Intrinsics.checkNotNull(item);
                    items.add(item);
                    Log.d("WebAppInterface", "Fetched item: " + item);
                }
                cursor.close();
                if (items.isEmpty()) {
                    jsonItems = "[]";
                } else {
                    jsonItems = CollectionsKt.joinToString$default(items, "\",\"", "[\"", "\"]", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
                }
                MainActivity.this.runOnUiThread(new MainActivity$WebAppInterface$$ExternalSyntheticLambda1(jsonItems, MainActivity.this));
            } catch (Exception e) {
                Log.e("WebAppInterface", "Error fetching NormalList: " + e.getMessage());
            }
        }

        /* access modifiers changed from: private */
        public static final void getNormalList$lambda$0(String $jsonItems, MainActivity this$02) {
            Intrinsics.checkNotNullParameter($jsonItems, "$jsonItems");
            Intrinsics.checkNotNullParameter(this$02, "this$0");
            Log.d("WebAppInterface", "Passing items to JavaScript: " + $jsonItems);
            WebView access$getMyWebView$p = this$02.myWebView;
            if (access$getMyWebView$p == null) {
                Intrinsics.throwUninitializedPropertyAccessException("myWebView");
                access$getMyWebView$p = null;
            }
            access$getMyWebView$p.evaluateJavascript("displayList(" + $jsonItems + ");", (ValueCallback) null);
        }

        @JavascriptInterface
        public final void getNiceList() {
            String jsonItems;
            try {
                SQLiteDatabase access$getDatabase$p = MainActivity.this.database;
                if (access$getDatabase$p == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p = null;
                }
                Cursor cursor = access$getDatabase$p.rawQuery("SELECT Item FROM NiceList", (String[]) null);
                List items = new ArrayList();
                while (cursor.moveToNext()) {
                    String string = cursor.getString(0);
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    items.add(string);
                }
                cursor.close();
                if (items.isEmpty()) {
                    jsonItems = "[]";
                } else {
                    jsonItems = CollectionsKt.joinToString$default(items, "\",\"", "[\"", "\"]", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
                }
                MainActivity.this.runOnUiThread(new MainActivity$WebAppInterface$$ExternalSyntheticLambda0(jsonItems, MainActivity.this));
            } catch (Exception e) {
                Log.e("WebAppInterface", "Error fetching NiceList: " + e.getMessage());
            }
        }

        /* access modifiers changed from: private */
        public static final void getNiceList$lambda$1(String $jsonItems, MainActivity this$02) {
            Intrinsics.checkNotNullParameter($jsonItems, "$jsonItems");
            Intrinsics.checkNotNullParameter(this$02, "this$0");
            Log.d("WebAppInterface", "Passing items to JavaScript: " + $jsonItems);
            WebView access$getMyWebView$p = this$02.myWebView;
            if (access$getMyWebView$p == null) {
                Intrinsics.throwUninitializedPropertyAccessException("myWebView");
                access$getMyWebView$p = null;
            }
            access$getMyWebView$p.evaluateJavascript("displayList(" + $jsonItems + ");", (ValueCallback) null);
        }

        @JavascriptInterface
        public final void getNaughtyList() {
            String jsonItems;
            try {
                SQLiteDatabase access$getDatabase$p = MainActivity.this.database;
                if (access$getDatabase$p == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p = null;
                }
                Cursor cursor = access$getDatabase$p.rawQuery("SELECT Item FROM NaughtyList", (String[]) null);
                List items = new ArrayList();
                while (cursor.moveToNext()) {
                    String string = cursor.getString(0);
                    Intrinsics.checkNotNullExpressionValue(string, "getString(...)");
                    items.add(string);
                }
                cursor.close();
                if (items.isEmpty()) {
                    jsonItems = "[]";
                } else {
                    jsonItems = CollectionsKt.joinToString$default(items, "\",\"", "[\"", "\"]", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
                }
                MainActivity.this.runOnUiThread(new MainActivity$WebAppInterface$$ExternalSyntheticLambda2(jsonItems, MainActivity.this));
            } catch (Exception e) {
                Log.e("WebAppInterface", "Error fetching NaughtyList: " + e.getMessage());
            }
        }

        /* access modifiers changed from: private */
        public static final void getNaughtyList$lambda$2(String $jsonItems, MainActivity this$02) {
            Intrinsics.checkNotNullParameter($jsonItems, "$jsonItems");
            Intrinsics.checkNotNullParameter(this$02, "this$0");
            Log.d("WebAppInterface", "Passing items to JavaScript: " + $jsonItems);
            WebView access$getMyWebView$p = this$02.myWebView;
            if (access$getMyWebView$p == null) {
                Intrinsics.throwUninitializedPropertyAccessException("myWebView");
                access$getMyWebView$p = null;
            }
            access$getMyWebView$p.evaluateJavascript("displayList(" + $jsonItems + ");", (ValueCallback) null);
        }

        private final void removeFromAllLists(String item) {
            try {
                SQLiteDatabase access$getDatabase$p = MainActivity.this.database;
                SQLiteDatabase sQLiteDatabase = null;
                if (access$getDatabase$p == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p = null;
                }
                access$getDatabase$p.execSQL("DELETE FROM NiceList WHERE Item = '" + item + "';");
                SQLiteDatabase access$getDatabase$p2 = MainActivity.this.database;
                if (access$getDatabase$p2 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                    access$getDatabase$p2 = null;
                }
                access$getDatabase$p2.execSQL("DELETE FROM NaughtyList WHERE Item = '" + item + "';");
                SQLiteDatabase access$getDatabase$p3 = MainActivity.this.database;
                if (access$getDatabase$p3 == null) {
                    Intrinsics.throwUninitializedPropertyAccessException("database");
                } else {
                    sQLiteDatabase = access$getDatabase$p3;
                }
                sQLiteDatabase.execSQL("DELETE FROM NormalList WHERE Item = '" + item + "';");
            } catch (Exception e) {
                Log.e("WebAppInterface", "Error removing item from all lists: " + e.getMessage());
            }
        }
    }
}
