package androidx.core.view;

import android.view.MotionEvent;
import android.view.View;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class DragStartHelper$$ExternalSyntheticLambda1 implements View.OnTouchListener {
    public final /* synthetic */ DragStartHelper f$0;

    public /* synthetic */ DragStartHelper$$ExternalSyntheticLambda1(DragStartHelper dragStartHelper) {
        this.f$0 = dragStartHelper;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        return this.f$0.onTouch(view, motionEvent);
    }
}
