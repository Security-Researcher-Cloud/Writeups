package androidx.core.view;

import kotlin.jvm.functions.Function0;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ViewKt$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ Function0 f$0;

    public /* synthetic */ ViewKt$$ExternalSyntheticLambda0(Function0 function0) {
        this.f$0 = function0;
    }

    public final void run() {
        ViewKt.postOnAnimationDelayed$lambda$1(this.f$0);
    }
}
