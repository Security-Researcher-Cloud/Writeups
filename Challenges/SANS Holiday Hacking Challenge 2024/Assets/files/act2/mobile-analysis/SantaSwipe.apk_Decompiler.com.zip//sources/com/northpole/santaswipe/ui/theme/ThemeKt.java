package com.northpole.santaswipe.ui.theme;

import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import kotlin.Metadata;

@Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a4\u0010\u0003\u001a\u00020\u00042\b\b\u0002\u0010\u0005\u001a\u00020\u00062\b\b\u0002\u0010\u0007\u001a\u00020\u00062\u0011\u0010\b\u001a\r\u0012\u0004\u0012\u00020\u00040\t¢\u0006\u0002\b\nH\u0007¢\u0006\u0002\u0010\u000b\"\u000e\u0010\u0000\u001a\u00020\u0001X\u0004¢\u0006\u0002\n\u0000\"\u000e\u0010\u0002\u001a\u00020\u0001X\u0004¢\u0006\u0002\n\u0000¨\u0006\f"}, d2 = {"DarkColorScheme", "Landroidx/compose/material3/ColorScheme;", "LightColorScheme", "SantaSwipeTheme", "", "darkTheme", "", "dynamicColor", "content", "Lkotlin/Function0;", "Landroidx/compose/runtime/Composable;", "(ZZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/Composer;II)V", "app_debug"}, k = 2, mv = {1, 9, 0}, xi = 48)
/* compiled from: Theme.kt */
public final class ThemeKt {
    private static final ColorScheme DarkColorScheme = ColorSchemeKt.m2884darkColorSchemeG1PFcw$default(ColorKt.getPurple80(), 0, 0, 0, 0, ColorKt.getPurpleGrey80(), 0, 0, 0, ColorKt.getPink80(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 536870366, (Object) null);
    private static final ColorScheme LightColorScheme = ColorSchemeKt.m2886lightColorSchemeG1PFcw$default(ColorKt.getPurple40(), 0, 0, 0, 0, ColorKt.getPurpleGrey40(), 0, 0, 0, ColorKt.getPink40(), 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 536870366, (Object) null);

    /* JADX WARNING: Removed duplicated region for block: B:50:0x0096  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x00b0  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x00d7  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x00fb  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static final void SantaSwipeTheme(boolean r9, boolean r10, kotlin.jvm.functions.Function2<? super androidx.compose.runtime.Composer, ? super java.lang.Integer, kotlin.Unit> r11, androidx.compose.runtime.Composer r12, int r13, int r14) {
        /*
            java.lang.String r0 = "content"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r11, r0)
            r0 = -1228674103(0xffffffffb6c3ebc9, float:-5.838902E-6)
            androidx.compose.runtime.Composer r12 = r12.startRestartGroup(r0)
            java.lang.String r1 = "C(SantaSwipeTheme)P(1,2)37@1099L21,52@1586L114:Theme.kt#migxf2"
            androidx.compose.runtime.ComposerKt.sourceInformation(r12, r1)
            r1 = r13
            r2 = r13 & 14
            if (r2 != 0) goto L_0x0024
            r2 = r14 & 1
            if (r2 != 0) goto L_0x0022
            boolean r2 = r12.changed((boolean) r9)
            if (r2 == 0) goto L_0x0022
            r2 = 4
            goto L_0x0023
        L_0x0022:
            r2 = 2
        L_0x0023:
            r1 = r1 | r2
        L_0x0024:
            r2 = r14 & 2
            if (r2 == 0) goto L_0x002b
            r1 = r1 | 48
            goto L_0x003b
        L_0x002b:
            r3 = r13 & 112(0x70, float:1.57E-43)
            if (r3 != 0) goto L_0x003b
            boolean r3 = r12.changed((boolean) r10)
            if (r3 == 0) goto L_0x0038
            r3 = 32
            goto L_0x003a
        L_0x0038:
            r3 = 16
        L_0x003a:
            r1 = r1 | r3
        L_0x003b:
            r3 = r14 & 4
            if (r3 == 0) goto L_0x0042
            r1 = r1 | 384(0x180, float:5.38E-43)
            goto L_0x0052
        L_0x0042:
            r3 = r13 & 896(0x380, float:1.256E-42)
            if (r3 != 0) goto L_0x0052
            boolean r3 = r12.changedInstance(r11)
            if (r3 == 0) goto L_0x004f
            r3 = 256(0x100, float:3.59E-43)
            goto L_0x0051
        L_0x004f:
            r3 = 128(0x80, float:1.794E-43)
        L_0x0051:
            r1 = r1 | r3
        L_0x0052:
            r3 = r1 & 731(0x2db, float:1.024E-42)
            r4 = 146(0x92, float:2.05E-43)
            if (r3 != r4) goto L_0x0064
            boolean r3 = r12.getSkipping()
            if (r3 != 0) goto L_0x005f
            goto L_0x0064
        L_0x005f:
            r12.skipToGroupEnd()
            goto L_0x00ff
        L_0x0064:
            r12.startDefaults()
            r3 = r13 & 1
            if (r3 == 0) goto L_0x007d
            boolean r3 = r12.getDefaultsInvalid()
            if (r3 == 0) goto L_0x0072
            goto L_0x007d
        L_0x0072:
            r12.skipToGroupEnd()
            r2 = r14 & 1
            if (r2 == 0) goto L_0x007b
            r1 = r1 & -15
        L_0x007b:
            r8 = r1
            goto L_0x008d
        L_0x007d:
            r3 = r14 & 1
            if (r3 == 0) goto L_0x0088
            r3 = 0
            boolean r9 = androidx.compose.foundation.DarkThemeKt.isSystemInDarkTheme(r12, r3)
            r1 = r1 & -15
        L_0x0088:
            if (r2 == 0) goto L_0x008c
            r10 = 1
            goto L_0x007b
        L_0x008c:
            r8 = r1
        L_0x008d:
            r12.endDefaults()
            boolean r1 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r1 == 0) goto L_0x009c
            r1 = -1
            java.lang.String r2 = "com.northpole.santaswipe.ui.theme.SantaSwipeTheme (Theme.kt:41)"
            androidx.compose.runtime.ComposerKt.traceEventStart(r0, r8, r1, r2)
        L_0x009c:
            r0 = 1733529939(0x67539153, float:9.991001E23)
            r12.startReplaceableGroup(r0)
            java.lang.String r0 = "44@1389L7"
            androidx.compose.runtime.ComposerKt.sourceInformation(r12, r0)
            if (r10 == 0) goto L_0x00d7
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 31
            if (r0 < r1) goto L_0x00d7
            androidx.compose.runtime.ProvidableCompositionLocal r0 = androidx.compose.ui.platform.AndroidCompositionLocals_androidKt.getLocalContext()
            androidx.compose.runtime.CompositionLocal r0 = (androidx.compose.runtime.CompositionLocal) r0
            r1 = 0
            r2 = 0
            r3 = 2023513938(0x789c5f52, float:2.5372864E34)
            java.lang.String r4 = "CC:CompositionLocal.kt#9igjgp"
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerStart(r12, r3, r4)
            java.lang.Object r3 = r12.consume(r0)
            androidx.compose.runtime.ComposerKt.sourceInformationMarkerEnd(r12)
            r0 = r3
            android.content.Context r0 = (android.content.Context) r0
            if (r9 == 0) goto L_0x00d1
            androidx.compose.material3.ColorScheme r1 = androidx.compose.material3.DynamicTonalPaletteKt.dynamicDarkColorScheme(r0)
            goto L_0x00e0
        L_0x00d1:
            androidx.compose.material3.ColorScheme r0 = androidx.compose.material3.DynamicTonalPaletteKt.dynamicLightColorScheme(r0)
            r1 = r0
            goto L_0x00e0
        L_0x00d7:
            if (r9 == 0) goto L_0x00dd
            androidx.compose.material3.ColorScheme r0 = DarkColorScheme
            r1 = r0
            goto L_0x00e0
        L_0x00dd:
            androidx.compose.material3.ColorScheme r0 = LightColorScheme
            r1 = r0
        L_0x00e0:
            r12.endReplaceableGroup()
            androidx.compose.material3.Typography r3 = com.northpole.santaswipe.ui.theme.TypeKt.getTypography()
            int r0 = r8 << 3
            r0 = r0 & 7168(0x1c00, float:1.0045E-41)
            r6 = r0 | 384(0x180, float:5.38E-43)
            r2 = 0
            r7 = 2
            r4 = r11
            r5 = r12
            androidx.compose.material3.MaterialThemeKt.MaterialTheme(r1, r2, r3, r4, r5, r6, r7)
            boolean r0 = androidx.compose.runtime.ComposerKt.isTraceInProgress()
            if (r0 == 0) goto L_0x00fe
            androidx.compose.runtime.ComposerKt.traceEventEnd()
        L_0x00fe:
            r1 = r8
        L_0x00ff:
            androidx.compose.runtime.ScopeUpdateScope r0 = r12.endRestartGroup()
            if (r0 != 0) goto L_0x0106
            goto L_0x0116
        L_0x0106:
            com.northpole.santaswipe.ui.theme.ThemeKt$SantaSwipeTheme$1 r8 = new com.northpole.santaswipe.ui.theme.ThemeKt$SantaSwipeTheme$1
            r2 = r8
            r3 = r9
            r4 = r10
            r5 = r11
            r6 = r13
            r7 = r14
            r2.<init>(r3, r4, r5, r6, r7)
            kotlin.jvm.functions.Function2 r8 = (kotlin.jvm.functions.Function2) r8
            r0.updateScope(r8)
        L_0x0116:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.northpole.santaswipe.ui.theme.ThemeKt.SantaSwipeTheme(boolean, boolean, kotlin.jvm.functions.Function2, androidx.compose.runtime.Composer, int, int):void");
    }
}
