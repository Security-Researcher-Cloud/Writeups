package androidx.core.util;

import java.util.Objects;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class Predicate$$ExternalSyntheticLambda1 implements Predicate {
    public final boolean test(Object obj) {
        return Objects.isNull(obj);
    }
}
