package androidx.core;

public final class R {

    public static final class attr {
        public static int alpha = 2130771968;
        public static int font = 2130771969;
        public static int fontProviderAuthority = 2130771970;
        public static int fontProviderCerts = 2130771971;
        public static int fontProviderFetchStrategy = 2130771972;
        public static int fontProviderFetchTimeout = 2130771973;
        public static int fontProviderPackage = 2130771974;
        public static int fontProviderQuery = 2130771975;
        public static int fontProviderSystemFontFamily = 2130771976;
        public static int fontStyle = 2130771977;
        public static int fontVariationSettings = 2130771978;
        public static int fontWeight = 2130771979;
        public static int lStar = 2130771980;
        public static int nestedScrollViewStyle = 2130771981;
        public static int queryPatterns = 2130771982;
        public static int shortcutMatchRequired = 2130771983;
        public static int ttcIndex = 2130771984;

        private attr() {
        }
    }

    public static final class color {
        public static int androidx_core_ripple_material_light = 2130837504;
        public static int androidx_core_secondary_text_default_material_light = 2130837505;
        public static int call_notification_answer_color = 2130837507;
        public static int call_notification_decline_color = 2130837508;
        public static int notification_action_color_filter = 2130837511;
        public static int notification_icon_bg_color = 2130837512;

        private color() {
        }
    }

    public static final class dimen {
        public static int compat_button_inset_horizontal_material = 2130903040;
        public static int compat_button_inset_vertical_material = 2130903041;
        public static int compat_button_padding_horizontal_material = 2130903042;
        public static int compat_button_padding_vertical_material = 2130903043;
        public static int compat_control_corner_material = 2130903044;
        public static int compat_notification_large_icon_max_height = 2130903045;
        public static int compat_notification_large_icon_max_width = 2130903046;
        public static int notification_action_icon_size = 2130903047;
        public static int notification_action_text_size = 2130903048;
        public static int notification_big_circle_margin = 2130903049;
        public static int notification_content_margin_start = 2130903050;
        public static int notification_large_icon_height = 2130903051;
        public static int notification_large_icon_width = 2130903052;
        public static int notification_main_column_padding_top = 2130903053;
        public static int notification_media_narrow_margin = 2130903054;
        public static int notification_right_icon_size = 2130903055;
        public static int notification_right_side_padding_top = 2130903056;
        public static int notification_small_icon_background_padding = 2130903057;
        public static int notification_small_icon_size_as_large = 2130903058;
        public static int notification_subtext_size = 2130903059;
        public static int notification_top_pad = 2130903060;
        public static int notification_top_pad_large_text = 2130903061;

        private dimen() {
        }
    }

    public static final class drawable {
        public static int ic_call_answer = 2130968576;
        public static int ic_call_answer_low = 2130968577;
        public static int ic_call_answer_video = 2130968578;
        public static int ic_call_answer_video_low = 2130968579;
        public static int ic_call_decline = 2130968580;
        public static int ic_call_decline_low = 2130968581;
        public static int notification_action_background = 2130968585;
        public static int notification_bg = 2130968586;
        public static int notification_bg_low = 2130968587;
        public static int notification_bg_low_normal = 2130968588;
        public static int notification_bg_low_pressed = 2130968589;
        public static int notification_bg_normal = 2130968590;
        public static int notification_bg_normal_pressed = 2130968591;
        public static int notification_icon_background = 2130968592;
        public static int notification_oversize_large_icon_bg = 2130968593;
        public static int notification_template_icon_bg = 2130968594;
        public static int notification_template_icon_low_bg = 2130968595;
        public static int notification_tile_bg = 2130968596;
        public static int notify_panel_notification_icon_bg = 2130968597;

        private drawable() {
        }
    }

    public static final class id {
        public static int accessibility_action_clickable_span = 2131034112;
        public static int accessibility_custom_action_0 = 2131034113;
        public static int accessibility_custom_action_1 = 2131034114;
        public static int accessibility_custom_action_10 = 2131034115;
        public static int accessibility_custom_action_11 = 2131034116;
        public static int accessibility_custom_action_12 = 2131034117;
        public static int accessibility_custom_action_13 = 2131034118;
        public static int accessibility_custom_action_14 = 2131034119;
        public static int accessibility_custom_action_15 = 2131034120;
        public static int accessibility_custom_action_16 = 2131034121;
        public static int accessibility_custom_action_17 = 2131034122;
        public static int accessibility_custom_action_18 = 2131034123;
        public static int accessibility_custom_action_19 = 2131034124;
        public static int accessibility_custom_action_2 = 2131034125;
        public static int accessibility_custom_action_20 = 2131034126;
        public static int accessibility_custom_action_21 = 2131034127;
        public static int accessibility_custom_action_22 = 2131034128;
        public static int accessibility_custom_action_23 = 2131034129;
        public static int accessibility_custom_action_24 = 2131034130;
        public static int accessibility_custom_action_25 = 2131034131;
        public static int accessibility_custom_action_26 = 2131034132;
        public static int accessibility_custom_action_27 = 2131034133;
        public static int accessibility_custom_action_28 = 2131034134;
        public static int accessibility_custom_action_29 = 2131034135;
        public static int accessibility_custom_action_3 = 2131034136;
        public static int accessibility_custom_action_30 = 2131034137;
        public static int accessibility_custom_action_31 = 2131034138;
        public static int accessibility_custom_action_4 = 2131034139;
        public static int accessibility_custom_action_5 = 2131034140;
        public static int accessibility_custom_action_6 = 2131034141;
        public static int accessibility_custom_action_7 = 2131034142;
        public static int accessibility_custom_action_8 = 2131034143;
        public static int accessibility_custom_action_9 = 2131034144;
        public static int action_container = 2131034145;
        public static int action_divider = 2131034146;
        public static int action_image = 2131034147;
        public static int action_text = 2131034148;
        public static int actions = 2131034149;
        public static int async = 2131034151;
        public static int blocking = 2131034152;
        public static int chronometer = 2131034153;
        public static int dialog_button = 2131034156;
        public static int edit_text_id = 2131034157;
        public static int forever = 2131034158;
        public static int hide_ime_id = 2131034159;
        public static int icon = 2131034161;
        public static int icon_group = 2131034162;
        public static int info = 2131034163;
        public static int italic = 2131034166;
        public static int line1 = 2131034167;
        public static int line3 = 2131034168;
        public static int normal = 2131034169;
        public static int notification_background = 2131034170;
        public static int notification_main_column = 2131034171;
        public static int notification_main_column_container = 2131034172;
        public static int right_icon = 2131034175;
        public static int right_side = 2131034176;
        public static int tag_accessibility_actions = 2131034177;
        public static int tag_accessibility_clickable_spans = 2131034178;
        public static int tag_accessibility_heading = 2131034179;
        public static int tag_accessibility_pane_title = 2131034180;
        public static int tag_on_apply_window_listener = 2131034181;
        public static int tag_on_receive_content_listener = 2131034182;
        public static int tag_on_receive_content_mime_types = 2131034183;
        public static int tag_screen_reader_focusable = 2131034184;
        public static int tag_state_description = 2131034185;
        public static int tag_transition_group = 2131034186;
        public static int tag_unhandled_key_event_manager = 2131034187;
        public static int tag_unhandled_key_listeners = 2131034188;
        public static int tag_window_insets_animation_callback = 2131034189;
        public static int text = 2131034190;
        public static int text2 = 2131034191;
        public static int time = 2131034192;
        public static int title = 2131034193;

        private id() {
        }
    }

    public static final class integer {
        public static int status_bar_notification_info_maxnum = 2131099648;

        private integer() {
        }
    }

    public static final class layout {
        public static int custom_dialog = 2131165185;
        public static int ime_base_split_test_activity = 2131165186;
        public static int ime_secondary_split_test_activity = 2131165187;
        public static int notification_action = 2131165188;
        public static int notification_action_tombstone = 2131165189;
        public static int notification_template_custom_big = 2131165190;
        public static int notification_template_icon_group = 2131165191;
        public static int notification_template_part_chronometer = 2131165192;
        public static int notification_template_part_time = 2131165193;

        private layout() {
        }
    }

    public static final class string {
        public static int call_notification_answer_action = 2131296262;
        public static int call_notification_answer_video_action = 2131296263;
        public static int call_notification_decline_action = 2131296264;
        public static int call_notification_hang_up_action = 2131296265;
        public static int call_notification_incoming_text = 2131296266;
        public static int call_notification_ongoing_text = 2131296267;
        public static int call_notification_screening_text = 2131296268;
        public static int status_bar_notification_info_overflow = 2131296320;

        private string() {
        }
    }

    public static final class style {
        public static int TextAppearance_Compat_Notification = 2131361795;
        public static int TextAppearance_Compat_Notification_Info = 2131361796;
        public static int TextAppearance_Compat_Notification_Line2 = 2131361797;
        public static int TextAppearance_Compat_Notification_Time = 2131361798;
        public static int TextAppearance_Compat_Notification_Title = 2131361799;
        public static int Widget_Compat_NotificationActionContainer = 2131361801;
        public static int Widget_Compat_NotificationActionText = 2131361802;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] Capability = {com.northpole.santaswipe.R.attr.queryPatterns, com.northpole.santaswipe.R.attr.shortcutMatchRequired};
        public static int Capability_queryPatterns = 0;
        public static int Capability_shortcutMatchRequired = 1;
        public static int[] ColorStateListItem = {16843173, 16843551, 16844359, com.northpole.santaswipe.R.attr.alpha, com.northpole.santaswipe.R.attr.lStar};
        public static int ColorStateListItem_alpha = 3;
        public static int ColorStateListItem_android_alpha = 1;
        public static int ColorStateListItem_android_color = 0;
        public static int ColorStateListItem_android_lStar = 2;
        public static int ColorStateListItem_lStar = 4;
        public static int[] FontFamily = {com.northpole.santaswipe.R.attr.fontProviderAuthority, com.northpole.santaswipe.R.attr.fontProviderCerts, com.northpole.santaswipe.R.attr.fontProviderFetchStrategy, com.northpole.santaswipe.R.attr.fontProviderFetchTimeout, com.northpole.santaswipe.R.attr.fontProviderPackage, com.northpole.santaswipe.R.attr.fontProviderQuery, com.northpole.santaswipe.R.attr.fontProviderSystemFontFamily};
        public static int[] FontFamilyFont = {16844082, 16844083, 16844095, 16844143, 16844144, com.northpole.santaswipe.R.attr.font, com.northpole.santaswipe.R.attr.fontStyle, com.northpole.santaswipe.R.attr.fontVariationSettings, com.northpole.santaswipe.R.attr.fontWeight, com.northpole.santaswipe.R.attr.ttcIndex};
        public static int FontFamilyFont_android_font = 0;
        public static int FontFamilyFont_android_fontStyle = 2;
        public static int FontFamilyFont_android_fontVariationSettings = 4;
        public static int FontFamilyFont_android_fontWeight = 1;
        public static int FontFamilyFont_android_ttcIndex = 3;
        public static int FontFamilyFont_font = 5;
        public static int FontFamilyFont_fontStyle = 6;
        public static int FontFamilyFont_fontVariationSettings = 7;
        public static int FontFamilyFont_fontWeight = 8;
        public static int FontFamilyFont_ttcIndex = 9;
        public static int FontFamily_fontProviderAuthority = 0;
        public static int FontFamily_fontProviderCerts = 1;
        public static int FontFamily_fontProviderFetchStrategy = 2;
        public static int FontFamily_fontProviderFetchTimeout = 3;
        public static int FontFamily_fontProviderPackage = 4;
        public static int FontFamily_fontProviderQuery = 5;
        public static int FontFamily_fontProviderSystemFontFamily = 6;
        public static int[] GradientColor = {16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
        public static int[] GradientColorItem = {16843173, 16844052};
        public static int GradientColorItem_android_color = 0;
        public static int GradientColorItem_android_offset = 1;
        public static int GradientColor_android_centerColor = 7;
        public static int GradientColor_android_centerX = 3;
        public static int GradientColor_android_centerY = 4;
        public static int GradientColor_android_endColor = 1;
        public static int GradientColor_android_endX = 10;
        public static int GradientColor_android_endY = 11;
        public static int GradientColor_android_gradientRadius = 5;
        public static int GradientColor_android_startColor = 0;
        public static int GradientColor_android_startX = 8;
        public static int GradientColor_android_startY = 9;
        public static int GradientColor_android_tileMode = 6;
        public static int GradientColor_android_type = 2;

        private styleable() {
        }
    }

    private R() {
    }
}
