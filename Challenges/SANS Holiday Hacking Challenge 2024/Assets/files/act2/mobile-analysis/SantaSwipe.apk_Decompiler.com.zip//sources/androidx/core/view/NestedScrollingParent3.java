package androidx.core.view;

import android.view.View;

public interface NestedScrollingParent3 extends NestedScrollingParent2 {
    void onNestedScroll(View view, int i, int i2, int i3, int i4, int i5, int[] iArr);
}
