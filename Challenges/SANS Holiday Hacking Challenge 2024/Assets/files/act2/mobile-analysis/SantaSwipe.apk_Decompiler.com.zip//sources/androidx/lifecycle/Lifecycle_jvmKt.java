package androidx.lifecycle;

import kotlin.Metadata;

@Metadata(d1 = {"\u0000\n\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000*\u001c\u0010\u0000\u001a\u0004\b\u0000\u0010\u0001\"\b\u0012\u0004\u0012\u0002H\u00010\u00022\b\u0012\u0004\u0012\u0002H\u00010\u0002¨\u0006\u0003"}, d2 = {"AtomicReference", "V", "Ljava/util/concurrent/atomic/AtomicReference;", "lifecycle-common"}, k = 2, mv = {1, 8, 0}, xi = 48)
/* compiled from: Lifecycle.jvm.kt */
public final class Lifecycle_jvmKt {
    public static /* synthetic */ void AtomicReference$annotations() {
    }
}
