package androidx.core.view;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class ViewCompat$$ExternalSyntheticLambda0 implements OnReceiveContentViewBehavior {
    public final ContentInfoCompat onReceiveContent(ContentInfoCompat contentInfoCompat) {
        return ViewCompat.lambda$static$0(contentInfoCompat);
    }
}
