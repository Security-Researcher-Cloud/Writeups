package com.northpole.santaswipe;

import com.northpole.santaswipe.MainActivity;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MainActivity$WebAppInterface$$ExternalSyntheticLambda0 implements Runnable {
    public final /* synthetic */ String f$0;
    public final /* synthetic */ MainActivity f$1;

    public /* synthetic */ MainActivity$WebAppInterface$$ExternalSyntheticLambda0(String str, MainActivity mainActivity) {
        this.f$0 = str;
        this.f$1 = mainActivity;
    }

    public final void run() {
        MainActivity.WebAppInterface.getNiceList$lambda$1(this.f$0, this.f$1);
    }
}
